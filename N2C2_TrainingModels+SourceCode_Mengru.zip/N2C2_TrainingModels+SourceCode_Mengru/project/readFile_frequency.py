#This file is to generate traning models into arff files, by opening filedialog, vsm is feature frequencies


import tkinter as tk
from tkinter import filedialog
import ntpath
import nltk
import os.path
import xml.etree.ElementTree as ET




root = tk.Tk()
root.withdraw()

# open files that is instances in the trainning models
test_file_path = filedialog.askopenfilenames()
print(test_file_path)


testOrder = open('testOrder.txt','w')

for i in  test_file_path:
    testOrder.write(i+'\n')


root2 = tk.Tk()
root2.withdraw()
# open feature txt files for the trainning models
features_file_path = filedialog.askopenfilenames()
print(features_file_path)


def judge(fileName,scName):
    sc=scNo(scName)
    tree = ET.parse(fileName)
    root = tree.getroot()
    label = root[1][sc].get('met')
    #print(SC1)

    return label


def processTrain(fileName,features,scName):
    tree = ET.parse(fileName)
    root = tree.getroot()
    medRecs = root[0].text.lower()
    medRecs = nltk.word_tokenize(medRecs)
    #fileID = ntpath.basename(fileName).split('.')[0]
    occurences=[]
   # occurences.append(fileID)
    for j in features:
        frequency=0
        for token in medRecs:
            if j == token:
                frequency = frequency+1
        occurences.append(str(frequency))

    if(judge(fileName,scName) == 'met'):
        occurences.append('Y')
    else:
        occurences.append('N')
    #print(fileName,'ok')
    #return occurences,fileID
    return occurences


def processTest(fileName,features):
    #print(fileName)
    tree = ET.parse(fileName)
    root = tree.getroot()
    medRecs = root[0].text.lower()
    medRecs=nltk.word_tokenize(medRecs)
    #fileID = ntpath.basename(fileName).split('.')[0]
    occurences=[]
    #occurences.append(fileID)
    for j in features:
        frequency=0
        for token in medRecs:
            if j == token:
                frequency = frequency+1
        occurences.append(str(frequency))
    occurences.append('?')
    #print(fileName,'ok')
    #return occurences,fileID
    return occurences






def scNo (scName):
    if scName == 'ABDOMINAL':
        return 0
    elif scName == 'ADVANCED-CAD':
        return 1
    elif scName == 'ALCOHOL-ABUSE':
        return 2
    elif scName == 'ASP-FOR-MI':
        return 3
    elif scName == 'CREATININE':
        return 4
    elif scName == 'DIETSUPP-2MOS':
        return 5
    elif scName == 'DRUG-ABUSE':
        return 6
    elif scName == 'ENGLISH':
        return 7
    elif scName == 'HBA1C':
        return 8
    elif scName == 'KETO-1YR':
        return 9
    elif scName == 'MAJOR-DIABETES':
        return 10
    elif scName == 'MAKES-DECISIONS':
        return 11
    elif scName == 'MI-6MOS':
        return 12

for i in features_file_path:
    r_features = open(i,'r')
    feature_list = r_features.read().split('\n')
    scName = ntpath.basename(i).split('.')[0]
    instances = []
    for j in test_file_path:
        basename = ntpath.basename(j).split('.')[0]
        r_test = open(j, 'r')
        #occurrence,fileID = processTrain(j,feature_list,scName)
        occurrence = processTrain(j,feature_list,scName)

        instances.append( occurrence)

    arff_file= scName +'.arff'
    #arff_file= '/Users/mengru/Documents/Meryl/n2c2/Training Models/tokenized/subset mi>0 arff/'+scName +'.arff'

    w = open(arff_file, "w")
    w.write("@RELATION "+scName+" \n")
    #w.write("@ATTRIBUTE ID NUMERIC\n")



    for attr in feature_list:
        w.write("@ATTRIBUTE " + attr+ " NUMERIC\n")
    w.write("@ATTRIBUTE "+scName+" {N,Y}\n")
    w.write("@Data\n")




    for inst in instances:
        for n in range(len(inst)):
            w.write(inst[n])
            if (n < len(inst) - 1):
                w.write(',')
        w.write('\n')
    w.close()
    print(scName+' ok')


# for i in test_file_path:
#     r_test = open(i,'r')
#     basename = ntpath.basename(i).split('.')[0]
#     for j in features_file_path:
#         scName = ntpath.basename(j).split('.')[0]
#         r_features = open(j, 'r')
#         feature_list = r_features.read().split('\n')
#         print(i)
#         instances = process(i,feature_list)
#         print(instances)
#
#         arff_file= basename + '-'+scName +'.arff'
#
#         w = open(arff_file, "w")
#         w.write("@RELATION "+scName+" \n")
#         for attr in feature_list:
#             w.write("@ATTRIBUTE " + attr+ " NUMERIC\n")
#         w.write("@ATTRIBUTE "+scName+" {N,Y}\n")
#         w.write("@Data\n")
#         for n in range(len(instances)):
#             w.write(instances[n])
#             if (n < len(instances) - 1):
#                 w.write(',')
#         w.close()