
# This program is used to calsulate mi scores of each feature
import xml.etree.ElementTree as ET
import os.path
import nltk

from nltk import word_tokenize
# from sklearn import metrics



# @author Mengru Wang #
from nltk import word_tokenize

import nltk
from nltk.corpus import stopwords
import os.path
import xml.etree.ElementTree as ET
import re
import os.path


recs=[]
labels = []


def judge(fileName):
    tag=1
    tree = ET.parse(fileName)
    root = tree.getroot()


    # abdominal = 0
    SC1 = root[tag][0].get('met')
    #print(SC1)

    return SC1



def preprocess(fileName):
    tree = ET.parse(fileName)
    root = tree.getroot()
    medRecs = root[0].text


    a = re.sub(r'\s+', ' ', medRecs)
    recs.append(a)
    if (judge(fileName) == 'met'):
        labels.append('Y')
    elif(judge(fileName) == 'not met'):
        labels.append('N')





def trainFile():
    fileNo=100
    count=0
    instances = []
    a=[]
    while(count<202):
        list=[]
        fileName = "train/" + str(fileNo) + ".xml"


        if(os.path.isfile(fileName)==True):
            instances.append(preprocess(fileName))

        else:
            while(os.path.isfile(fileName)==False):
                fileNo = fileNo + 1
                fileName = "train/" + str(fileNo) + ".xml"

            #findFeature(fileName)
            #print(fileNo)
            instances.append(preprocess(fileName))
            #print(fileNo)

        fileNo = fileNo + 1
        count+=1
    #print(instances)
    return instances



trainFile()





import numpy as np



# feature files
f1 = open("sc7.txt", "r")

#output files
f2 = open("mi_out.txt", "w")

f2.truncate()
str1 = f1.read()

feature_list = str1.split('\n')
print(len(feature_list))

fileNo = 100

count = 0
count_Y = 0
count_N = 0
abs_Y_list = []

Ylist=[]
Nlist=[]



for i in range(0,len(labels)):
    if labels[i] == 'Y':
        count_Y=count_Y + 1
        Ylist.append(recs[i])
        print(Ylist)
    else:
        count_N = count_N + 1
        Nlist.append(recs[i])


print(count_Y,count_N)


def cal_mi(feature):
    count_feature_Y = 0
    count_feature_N = 0
    mi = 0
    zero = 0
    for f in Ylist:
        list = nltk.word_tokenize(f)
        list = [item.lower() for item in list]
        if feature in list:
            count_feature_Y = count_feature_Y + 1
    for f in Nlist:

        list = nltk.word_tokenize(f)
        list = [item.lower() for item in list]
        if feature in list:
            count_feature_N = count_feature_N + 1
    left_Y = count_Y - count_feature_Y
    left_N = count_N - count_feature_N

    if count_feature_N == 0 and count_feature_Y > 0:
        abs_Y_list.append(feature)
        print('Ofrom here')

    elif (count_feature_Y == zero) or (left_N == zero) or (count_feature_N == zero) or (count_feature_Y == zero):

        mi = -1
    else:

        count_feature = count_feature_Y + count_feature_N
        count_left = 202 - count_feature
        t1 = (202 * count_feature_Y) / float(count_Y * count_feature)
        t2 = (202 * count_feature_N) / float(count_N * count_feature)
        t3 = (202 * left_Y) / float(count_Y * count_left)
        t4 = (202 * left_N) / float(count_N * count_left)
        mi = ((count_feature_Y / float(202)) * np.log2(t1)) + ((count_feature_N / float(202)) * np.log2(t2)) + (
                    (left_Y / float(202)) * np.log2(t3)) + ((left_N / float(202)) * np.log2(t4))
        print('o is here')
    # print count_feature_Y
    # print count_feature_N
    return (mi)


print(abs_Y_list)
feature_dict = {}
n = 0
for feature in feature_list:
    f_mi = cal_mi(feature)
    feature_dict[feature] = f_mi
    n = n + 1
    print(n)
    print(feature, f_mi)
    f2.write(feature + " " + str(float(f_mi)))
    f2.write('\n')
feature_sort = sorted(feature_dict.items(), key=lambda e: e[1], reverse=True)


f2.write("\n Sorted on score \n")
for i in feature_sort:
     f2.write(i[0])
     f2.write('\n')
i = 0

f2.write("\n Features only occur to 'met' files \n")

for i in abs_Y_list:
     f2.write(i)
     f2.write('\n')

f1.close()
f2.close()





