
# this program is to apply vote scheme for arff file cross validation predication (maily with xml file ID)
from xml.dom import minidom

import tkinter as tk
from tkinter import filedialog
import ntpath

root = tk.Tk()
root.withdraw()

# open cfs method predictions
cfs = filedialog.askopenfilenames()


root2 = tk.Tk()
root2.withdraw()

# open correlation 200 method predictions
correlation = filedialog.askopenfilenames()



root3= tk.Tk()
root3.withdraw()

# open mutual 200 method predictions
mutual = filedialog.askopenfilenames()


def AddSC(fileName):
    # fname=fileName.replace("test/","")
    basename = ntpath.basename(fileName)
    newfile = "result/" + basename
    doc = minidom.parse(fileName)
    root = doc.getElementsByTagName("TAGS")
    node0 = doc.createElement("ABDOMINAL")
    node1 = doc.createElement("ADVANCED-CAD")
    node2 = doc.createElement("ALCOHOL-ABUSE")
    node3 = doc.createElement("ASP-FOR-MI")
    node4 = doc.createElement("CREATININE")
    node5 = doc.createElement("DIETSUPP-2MOS")
    node6 = doc.createElement("DRUG-ABUSE")
    node7 = doc.createElement("ENGLISH")
    node8 = doc.createElement("HBA1C")
    node9 = doc.createElement("KETO-1YR")
    node10 = doc.createElement("MAJOR-DIABETES")
    node11 = doc.createElement("MAKES-DECISIONS")
    node12 = doc.createElement("MI-6MOS")

    for i,j,k in zip(cfs,correlation,mutual):
        testname = basename.split('.')[0]
        if 'abdominal' in i.lower():

            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')
            #print(wekaResult_mutual,wekaResult_corre,wekaResult_cfs)

            counter=0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1=line1.split(',')
                    prediction = line1[len(line1)-2]
                    print('1 ok')
                    if prediction == "Y":
                        counter+=1



            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2=line2.split(',')
                    prediction = line2[len(line2)-2]
                    print('2 ok')
                    if prediction == "Y":
                        counter+=1


            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3=line3.split(',')
                    prediction = line3[len(line3)-2]
                    print('3 ok')

                    if prediction == "Y":
                        counter+=1
            print(counter)

            if counter >= 2:

                node0.setAttribute("met", "met")
            else:
                node0.setAttribute('met', "not met")

            root[0].appendChild(node0)
            print('sc1 ok')

        if 'advanced-cad' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node1.setAttribute("met", "met")
            else:
                node1.setAttribute('met', "not met")

            root[0].appendChild(node1)
            print('sc2 ok')

        if 'alcohol-abuse' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node2.setAttribute("met", "met")
            else:
                node2.setAttribute('met', "not met")

            root[0].appendChild(node2)

            print('sc3 ok')

        if 'asp-for-mi' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node3.setAttribute("met", "met")
            else:
                node3.setAttribute('met', "not met")

            root[0].appendChild(node3)

            print('sc4 ok')

        if 'creatinine' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node4.setAttribute("met", "met")
            else:
                node4.setAttribute('met', "not met")

            root[0].appendChild(node4)

            print('sc5 ok')

        if 'dietsupp-2mos' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node5.setAttribute("met", "met")
            else:
                node5.setAttribute('met', "not met")

            root[0].appendChild(node5)
            print('sc6 ok')

        if 'drug-abuse' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node6.setAttribute("met", "met")
            else:
                node6.setAttribute('met', "not met")

            root[0].appendChild(node6)
            print('sc7 ok')

        if 'english' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node7.setAttribute("met", "met")
            else:
                node7.setAttribute('met', "not met")

            root[0].appendChild(node7)
            print('sc8 ok')

        if 'hba1c' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node8.setAttribute("met", "met")
            else:
                node8.setAttribute('met', "not met")

            root[0].appendChild(node8)
            print('sc9 ok')

        if 'keto-1yr' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node9.setAttribute("met", "met")
            else:
                node9.setAttribute('met', "not met")

            root[0].appendChild(node9)
            print('sc10 ok')

        if 'major-diabetes' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node10.setAttribute("met", "met")
            else:
                node10.setAttribute('met', "not met")

            root[0].appendChild(node10)
            print('sc11 ok')

        if 'makes-decisions' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node11.setAttribute("met", "met")
            else:
                node11.setAttribute('met', "not met")

            root[0].appendChild(node11)
            print('sc12 ok')

        if 'mi-6mos' in i.lower():
            wekaResult_cfs = open(i, 'r')
            wekaResult_corre = open(j, 'r')
            wekaResult_mutual = open(k, 'r')

            counter = 0
            for line1 in wekaResult_cfs:
                if ('@' not in line1) and (testname in line1):
                    line1 = line1.split(',')
                    prediction = line1[len(line1) - 2]
                    if prediction == "Y":
                        counter += 1

            for line2 in wekaResult_corre:
                if ('@' not in line2) and (testname in line2):
                    line2 = line2.split(',')
                    prediction = line2[len(line2) - 2]
                    if prediction == "Y":
                        counter += 1

            for line3 in wekaResult_mutual:
                if ('@' not in line3) and (testname in line3):
                    line3 = line3.split(',')
                    prediction = line3[len(line3) - 2]
                    if prediction == "Y":
                        counter += 1
            print(counter)

            if counter >= 2:
                node12.setAttribute("met", "met")
            else:
                node12.setAttribute('met', "not met")

            root[0].appendChild(node12)
            print('sc13 ok')

    f = open(newfile, 'w')
    f.truncate()
    doc.writexml(f, addindent='', newl='\n', encoding='UTF-8')
    f.close()


test_file_path = []
getOder = open('testOrder.txt', 'r')

for line in getOder:
    if len(line) > 2:
        test_file_path.append(line.strip('\n'))
print(test_file_path)


for test in test_file_path:
    AddSC(test)


