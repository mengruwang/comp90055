# This program is used to delete selection criteria tags in xml file
import xml.dom.minidom as minidom

import tkinter as tk
from tkinter import filedialog
import ntpath
import xml.etree.ElementTree as ET




def delm(fileName,outName):
    dom = minidom.parse(fileName)
    root = dom.getElementsByTagName("ABDOMINAL")[0]
    root1 = dom.getElementsByTagName("ADVANCED-CAD")[0]
    root2 = dom.getElementsByTagName("ALCOHOL-ABUSE")[0]
    root3 = dom.getElementsByTagName("ASP-FOR-MI")[0]
    root4 = dom.getElementsByTagName("CREATININE")[0]
    root5 = dom.getElementsByTagName("DIETSUPP-2MOS")[0]
    root6 = dom.getElementsByTagName("DRUG-ABUSE")[0]
    root7 = dom.getElementsByTagName("ENGLISH")[0]
    root8 = dom.getElementsByTagName("HBA1C")[0]
    root9 = dom.getElementsByTagName("KETO-1YR")[0]
    root10 = dom.getElementsByTagName("MAJOR-DIABETES")[0]
    root11 = dom.getElementsByTagName("MAKES-DECISIONS")[0]
    root12 = dom.getElementsByTagName("MI-6MOS")[0]



    root.parentNode.removeChild(root)
    root1.parentNode.removeChild(root1)
    root2.parentNode.removeChild(root2)
    root3.parentNode.removeChild(root3)
    root4.parentNode.removeChild(root4)
    root5.parentNode.removeChild(root5)
    root6.parentNode.removeChild(root6)
    root7.parentNode.removeChild(root7)
    root8.parentNode.removeChild(root8)
    root9.parentNode.removeChild(root9)
    root10.parentNode.removeChild(root10)
    root11.parentNode.removeChild(root11)
    root12.parentNode.removeChild(root12)




    f =  open(outName,  'w')
    f.truncate()
    dom.writexml(f, addindent = '' , newl = '' ,encoding = 'UTF-8' )
    f.close()


    tree = ET.parse(outName)
    content = tree.getroot()
    for elem in content.iter('*'):
        print(elem)
        if (len(elem.text)) > 5 and (len(elem.text)) < 15:
            elem.text = '\n'
        if (len(elem.text)>4000):
            elem.text='<![CDATA['+elem.text+']]>'
    output = open(outName, 'wb')
    output.write(b'<?xml version="1.0" encoding="UTF-8" ?>\n')
    output.write(ET.tostring(content))
    print(ET.tostring(content))


root = tk.Tk()
root.withdraw()


train_file_path = filedialog.askopenfilenames()
print(train_file_path)


for  i in train_file_path:
    fname='test/'+ntpath.basename(i)
    delm(i,fname)